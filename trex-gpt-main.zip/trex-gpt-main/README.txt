Just save this directory somewhere nice and cozy.  Tis unpacked, so simply point your browser (chrome or opera) to this directory.

To use, simply highlight a portion of a webpage and click the extension icon.


Enjoy!

-TrexLab